<?php
session_start();
if ($_SESSION['validation'] == "true" && isset($_POST['reserve'])) {
    // echo "".$_SESSION['u_id'];

    require_once 'connectdb.php';

    echo  $chk = "SELECT u_id from rooms WHERE u_id='" . $_SESSION['u_id'] . "'";
    $result_chk = mysqli_query($conn, $chk);
    if (mysqli_num_rows($result_chk) == 1) {
        echo "Room Already allocated<br>";
        $_SESSION['status'] = "allocated";
        header("location:book.php");
    } else {
        echo "no room allocated<br>";

        echo $sql = "UPDATE rooms SET u_id='" . $_SESSION['u_id'] . "' WHERE r_no='" . $_POST['room-no'] . "'";
        try {
            echo "updating rooms<br>";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<br>success room updated<br>";

                echo  $sql2 = "INSERT INTO booked_rooms( u_id, r_no, gen, dob, clg, branch, sem, bg, address, p_mob) VALUES ('" . $_SESSION['u_id'] . "','"  . trim($_POST['room-no']) . "','" . trim($_POST['gender']) . "','" . trim($_POST['dob']) . "','" . trim(($_POST['clg'])) . "','" . trim($_POST['branch']) . "','" . trim($_POST['sem']) . "','" . trim($_POST['bg']) . "','" . trim($_POST['address']) . "','" . trim($_POST['mob-2']) . "')";
                $result2 = mysqli_query($conn, $sql2);
                if ($result2) {
                    echo "<br>success room booked<br>";
                    $_SESSION['status'] = "booked";
                    header("location:book.php");
                } else {
                    echo "failed to book room<br>";
                    $_SESSION['status'] = "failed";
                    header("location:book.php");
                }
            } else {
                echo "Failed to update rooms<br>";
                $_SESSION['status'] = "failed";
                header("location:book.php");
            }
            //   $row=mysqli_fetch_assoc($result);
        } catch (Exception $e) {
            echo "Querry Failed : " . $e->getMessage();
            $_SESSION['status'] = "failed";
            header("location:book.php");
        }
    }
} else {
    header("location:login.php");
}
