<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbName = "hostel2";

// $db_exist = mysqli_select_db(mysqli_connect($servername, $username, $password), "rxnew");
$conn = new mysqli($servername,$username,$password,$dbName);

// Check connection
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}
?>