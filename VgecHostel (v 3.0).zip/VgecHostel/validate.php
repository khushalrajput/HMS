<?php
session_start();

if(isset($_POST['login'])){
    $_POST['login']="success";
require_once 'connectdb.php';
require_once 'secure.php';

$sql1="select * from wardens where email='".$_POST['email']."'";
try {
    $result1 = mysqli_query($conn, $sql1);
}
catch (Exception $e) {

 }
$sql2="select * from rectors where email='".$_POST['email']."'";
try {
    $result2 = mysqli_query($conn, $sql2);
}
catch (Exception $e) {

 }
if($_POST['email']=="admin@gmail.com" && $_POST['pass']=="admin"){
    $_SESSION['admin']="true";
    header("location:admin/index.php");
}
else if(mysqli_num_rows($result1)==1){
    $_SESSION['admin']="true";
    header("location:warden/");
}
else if(mysqli_num_rows($result2)==1){
    $_SESSION['admin']="true";
    header("location:rector/");
}
else{
$sql="select * from users where email='".$_POST['email']."'";

try {
    echo $sql;
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result)==1) {
        echo "done";

        $row=mysqli_fetch_assoc($result);

        if(trim($_POST['email'])==$row['email'] && trim($_POST['pass'])==decrypt($row['pass'])){
            $_SESSION['status'] = "success_login";
            $_SESSION['validation'] = "true";
            $_SESSION['u_id'] = $row['u_id'];
            header("location:home.php");
            mysqli_close($conn);
        }
        else{
            $_SESSION['status'] = "incorrect";
            header("location:login.php");
            mysqli_close($conn);
        }
        
    }
    else{
        echo "user not exist";
        $_SESSION['status'] = "no_reg";
        header("location:login.php");
        mysqli_close($conn);
    }

} catch (Exception $e) {
    $_SESSION['status'] = "fail_login";
    echo "fails";
    header("location:login.php");
    mysqli_close($conn);
}
}
}
else{
    header("location:login.php");
}

?>