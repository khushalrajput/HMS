<?php
session_start();
require_once 'connectdb.php';

 ECHO $sql = "INSERT INTO admissions(u_id,name,enroll,gen,dob,clg,branch,sem,bg,address,pin,rank,cast,p_mob,status) VALUES ('$_SESSION[u_id]','$_POST[name]', '$_POST[enroll]','$_POST[gender]','$_POST[dob]','$_POST[clg]','$_POST[branch]','$_POST[sem]' ,'$_POST[bg]','$_POST[address]','$_POST[pin]','$_POST[merit]','$_POST[cast]','$_POST[mob2]' ,'inspection')";
if(mysqli_query($conn, $sql)){

    $_SESSION['status'] = "booked";
    header("location:book.php");
}else{
    $_SESSION['status'] = "failed";
    header("location:book.php");
}
?>