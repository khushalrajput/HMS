<?php
session_start();

// if ($_SESSION['admin'] == "true") {

    require_once '../connectdb.php';



?>
    <!doctype html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <link rel="stylesheet" href="cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="css/index.css">
        
        <style>
            #hostelers {
                background-color: #00d4e8;
                color: white;
                font-weight: 800;
            }
        </style>
    </head>

    <body>
        <?php include 'components/sidebar.php';  ?>
        <div class="content">
        <div class="container">
        <div class="text-center fw-bold fs-2  my-5">
                Hostelers
            </div>
            <table class="table table-striped border table-hover">
                <tr class="table-dark">
                    <th>Sr. No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile No.</th>
                    <th>Parent Mob No.</th>
                    <th>Gender</th>
                    <th>DOB</th>
                    <th>College</th>
                    <th>Branch</th>
                    <th>Sem</th>
                    <th>Blood Group</th>
                    <th>Address</th>
                    <th>Room No.</th>
                    <th>Room Type</th>
                </tr>
                <?php
                $sql = "SELECT * from booked_rooms";
                $sr=1;
                try {

                    $result = mysqli_query($conn, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {

                        $sql2 = "SELECT * from users where u_id='".$row['u_id']."'";
                        $result2 = mysqli_query($conn, $sql2);
                        $row2=mysqli_fetch_assoc($result2);
                        // echo $row2['name'];
                        $sql3 = "SELECT r_type from rooms where r_no='".$row['r_no']."'";
                        $result3 = mysqli_query($conn, $sql3);
                        $row3=mysqli_fetch_assoc($result3);
                ?>
                        <tr>
                            <td><?php echo $sr; ?></td>
                            <td><?php echo $row2['name']; ?></td>
                            <td><?php echo $row2['email']; ?></td>
                            <td><?php echo $row2['mob']; ?></td>
                            <td><?php echo $row['p_mob']; ?></td>
                            <td><?php echo $row['gen']; ?></td>
                            <td><?php echo $row['dob']; ?></td>
                            <td><?php echo $row['clg']; ?></td>
                            <td><?php echo $row['branch']; ?></td>
                            <td><?php echo $row['sem']; ?></td>
                            <td><?php echo $row['bg']; ?></td>
                            <td><?php echo $row['address']; ?></td>
                            <td><?php echo $row['r_no']; ?></td>
                            <td><?php echo $row3['r_type']; ?></td>
                        </tr>
                <?php
                $sr++;
                    }
                } catch (Exception $e) {
                    echo $e->getMessage();
                    // header("location:../login.php");
                }
                ?>
            </table>
        </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    </body>

    </html>

<?php
// } else {
//     header("location:../login.php");
// }
?>