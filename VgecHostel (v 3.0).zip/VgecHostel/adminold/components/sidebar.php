
<div class="sidebar">
<a id="home" class="" href="index.php">Home</a>
  <a id="users" class="" href="registered.php">Registered Users</a>
  <a id="hostelers" href="hostelers.php">Hostelers</a>
  <a id="rooms" href="rooms.php">Rooms</a>
  <a id="feed" href="feedbacks.php">Feedbacks</a>
  <a id="" href="../logout.php">Logout</a>
  <!-- <a href="#about">About</a> -->
</div>

