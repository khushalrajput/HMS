
<?php
session_start();
if( $_SESSION['validation']=="true"){
  ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>VGEC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/index.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="shortcut icon" href="assets/img/logo.png" type="image/x-icon">
</head>
  <body>

    <!-- header -->
    <?php include_once 'assets/components/header_login.php'; ?>

    <!-- hero carousel -->
    <?php include_once 'assets/components/hero-carousel.php'; ?>

     <!-- Home -->
    <div id="Home" class="introduction section ">
        <div class="container">
        <h1 class="text-center heading" data-aos="fade-down">VGEC Hostel</h1>
        <div class="fluid-container d-flex justify-content-center align-items-center flex-wrap">

            <div data-aos="fade-right" data-aos-duration="2000" class="row  d-flex justify-content-center align-items-center">

                <div class="col-11 col-sm-5 d-flex justify-content-center align-items-center">
                 <div class="rotate-logo  d-flex justify-content-center align-items-center">
                   <img src="assets/img/logo.png" height="240px" width="240px" alt="">
                 </div>
                </div>

                <div data-aos="fade-left" data-aos-duration="1800" class="col-11 col-sm-7 d-flex justify-content-center align-items-center">
                <div class="content  ">
                    <p class="first">  We provides excellent accommodation to its students. The students are provided with all the amenities so that their stay here becomes a worthwhile experience.</p>
                    <p>he institute has a boys hostel with capacity of 540 students and a girls hostel with capacity of 180 students. There are messes in the both hostel campus. Many newspapers and magazines are subscribed for the hostel library. Entertainment facilities like TV room, badminton room, gymnasium are also available in hostel. Outdoor and indoor games are also provided for the hostelites. University health centre has extended its services to the students of our hostel. The hostel is administered by the rector and four wardens.</p>
                    <center>
        <table class="mt-5 border hover  table table-striped w-100" data-aos="zoom-in" data-aos-duration="2000">
          <tr>
            <td class="text-center" style="width: 80%">Number of Rooms</td>
            <td style="width: 20%">180</td>
          </tr>
          <tr>
            <td class="text-center" style="width: 80%">Capacity</td>
            <td style="width: 20%">540</td>
          </tr>
          <tr>
            <td class="text-center" style="width: 80%">Guest Rooms</td>
            <td style="width: 20%">2</td>
          </tr>
          <tr>
            <td class="text-center" style="width: 80%">T.V. Room</td>
            <td style="width: 20%">1</td>
          </tr>
          <tr>
            <td class="text-center" style="width: 80%">Mess</td>
            <td style="width: 20%">1</td>
          </tr>
          <tr>
            <td class="text-center" style="width: 80%">Reading Room</td>
            <td style="width: 20%">1</td>
          </tr>

        </table>
        </center>
                </div>
                </div>

            </div>
        </div>
        </div>
    </div>

        <!-- services -->
        <div id="Services" class="service section ">
        <div class="container">
        <h1 class="text-center heading pb-5"  data-aos="fade-down">Our Services</h1>

        <div class="row d-flex mt-5 justify-content-evenly ">

          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-alarm" viewBox="0 0 16 16">
                    <path d="M8.5 5.5a.5.5 0 0 0-1 0v3.362l-1.429 2.38a.5.5 0 1 0 .858.515l1.5-2.5A.5.5 0 0 0 8.5 9V5.5z"/>
                    <path d="M6.5 0a.5.5 0 0 0 0 1H7v1.07a7.001 7.001 0 0 0-3.273 12.474l-.602.602a.5.5 0 0 0 .707.708l.746-.746A6.97 6.97 0 0 0 8 16a6.97 6.97 0 0 0 3.422-.892l.746.746a.5.5 0 0 0 .707-.708l-.601-.602A7.001 7.001 0 0 0 9 2.07V1h.5a.5.5 0 0 0 0-1h-3zm1.038 3.018a6.093 6.093 0 0 1 .924 0 6 6 0 1 1-.924 0zM0 3.5c0 .753.333 1.429.86 1.887A8.035 8.035 0 0 1 4.387 1.86 2.5 2.5 0 0 0 0 3.5zM13.5 1c-.753 0-1.429.333-1.887.86a8.035 8.035 0 0 1 3.527 3.527A2.5 2.5 0 0 0 13.5 1z"/>
                    </svg>
              </div>
              <h4 class="title">Support</h4>
              <p class="description">We Provide full 24X7 support to our Students.</p>
            </div>
          </div>
        
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-fingerprint" viewBox="0 0 16 16">
                <path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"/>
                <path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"/>
                <path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"/>
                <path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"/>
                <path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"/>
                </svg>
              </div>
              <h4 class="title">Security</h4>
              <p class="description">We provide best secuity.</p>
            </div>
          </div>
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-eye" viewBox="0 0 16 16">
                 <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                 <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                </svg>
              </div>
              <h4 class="title">Virtual Tour</h4>
              <p class="description">Students can Tour there rooms virtually and can choose one.</p>
            </div>
          </div>
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-compass" viewBox="0 0 16 16">
        <path d="M8 16.016a7.5 7.5 0 0 0 1.962-14.74A1 1 0 0 0 9 0H7a1 1 0 0 0-.962 1.276A7.5 7.5 0 0 0 8 16.016zm6.5-7.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
        <path d="m6.94 7.44 4.95-2.83-2.83 4.95-4.949 2.83 2.828-4.95z"/>
        </svg>
              </div>
              <h4 class="title">Remote</h4>
              <p class="description">We Provide full remote control to students.</p>
            </div>
          </div>
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-trophy" viewBox="0 0 16 16">
         <path d="M2.5.5A.5.5 0 0 1 3 0h10a.5.5 0 0 1 .5.5c0 .538-.012 1.05-.034 1.536a3 3 0 1 1-1.133 5.89c-.79 1.865-1.878 2.777-2.833 3.011v2.173l1.425.356c.194.048.377.135.537.255L13.3 15.1a.5.5 0 0 1-.3.9H3a.5.5 0 0 1-.3-.9l1.838-1.379c.16-.12.343-.207.537-.255L6.5 13.11v-2.173c-.955-.234-2.043-1.146-2.833-3.012a3 3 0 1 1-1.132-5.89A33.076 33.076 0 0 1 2.5.5zm.099 2.54a2 2 0 0 0 .72 3.935c-.333-1.05-.588-2.346-.72-3.935zm10.083 3.935a2 2 0 0 0 .72-3.935c-.133 1.59-.388 2.885-.72 3.935zM3.504 1c.007.517.026 1.006.056 1.469.13 2.028.457 3.546.87 4.667C5.294 9.48 6.484 10 7 10a.5.5 0 0 1 .5.5v2.61a1 1 0 0 1-.757.97l-1.426.356a.5.5 0 0 0-.179.085L4.5 15h7l-.638-.479a.501.501 0 0 0-.18-.085l-1.425-.356a1 1 0 0 1-.757-.97V10.5A.5.5 0 0 1 9 10c.516 0 1.706-.52 2.57-2.864.413-1.12.74-2.64.87-4.667.03-.463.049-.952.056-1.469H3.504z"/>
        </svg>
              </div>
              <h4 class="title">Categories</h4>
              <p class="description">We Provide large range of room Categories.</p>
            </div>
          </div>
        </div>
        </div>
    </div>

    <!-- Hostel at a glance -->
    <div id="Glances" class="glance section ">
        <div class="container">
        <h1 class="text-center heading"  data-aos="fade-down">Hostel At Glance</h1>

        <div class="main d-flex justify-content-center align-items-center pt-5 flex-wrap">
          <img class="mx-3 mt-4" src="assets/img/h1.png" data-aos="zoom-in-down" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/h2.png" data-aos="zoom-in-down" data-aos-duration="1800"  alt="" width="300px" height="180px"  style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/h3.png" data-aos="zoom-in-down" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/fac1.jpg" data-aos="zoom-in-right" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/fac2.jpg" data-aos="zoom-out" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/fac3.jpg" data-aos="zoom-in-left" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/w1.png" data-aos="zoom-in-up" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/s1.jpg" data-aos="zoom-in-up" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
          <img class="mx-3 mt-4" src="assets/img/s4.jpg" data-aos="zoom-in-up" data-aos-duration="1800" alt="" width="300px" height="180px" style="box-shadow: 2px 2px 10px 1px grey">
        </div>
        </div>
    </div>




    <!-- facilities -->
    <div id="Facility" class="facility section ">
        <div class="container">
        <h1 class="text-center heading pb-5"  data-aos="fade-down">Our Facilities</h1>

        <div class="row d-flex mt-5 justify-content-evenly ">

          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
            <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-fingerprint" viewBox="0 0 16 16">
                <path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"/>
                <path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"/>
                <path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"/>
                <path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"/>
                <path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"/>
                </svg>
              </div>
              <h4 class="title">Security</h4>
              <p class="description">Security check at the main gate of each Hostel. Lady Warden at girl’s hostels.</p>
            </div>
          </div>
        
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-emoji-laughing" viewBox="0 0 16 16">
              <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
              <path d="M12.331 9.5a1 1 0 0 1 0 1A4.998 4.998 0 0 1 8 13a4.998 4.998 0 0 1-4.33-2.5A1 1 0 0 1 4.535 9h6.93a1 1 0 0 1 .866.5zM7 6.5c0 .828-.448 0-1 0s-1 .828-1 0S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 0-1 0s-1 .828-1 0S9.448 5 10 5s1 .672 1 1.5z"/>
            </svg>
              </div>
              <h4 class="title">Sports</h4>
              <p class="description">Hostel provides sports space.</p>
            </div>
          </div>
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-bus-front-fill" viewBox="0 0 16 16">
              <path d="M16 7a1 1 0 0 1-1 1v3.5c0 .818-.393 1.544-1 2v2a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5V14H5v1.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-2a2.496 2.496 0 0 1-1-2V8a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1V2.64C1 1.452 1.845.408 3.064.268A43.608 43.608 0 0 1 8 0c2.1 0 3.792.136 4.936.268C14.155.408 15 1.452 15 2.64V4a1 1 0 0 1 1 1v2ZM3.552 3.22A43.306 43.306 0 0 1 8 3c1.837 0 3.353.107 4.448.22a.5.5 0 0 0 .104-.994A44.304 44.304 0 0 0 8 2c-1.876 0-3.426.109-4.552.226a.5.5 0 1 0 .104.994ZM8 4c-1.876 0-3.426.109-4.552.226A.5.5 0 0 0 3 4.723v3.554a.5.5 0 0 0 .448.497C4.574 8.891 6.124 9 8 9c1.876 0 3.426-.109 4.552-.226A.5.5 0 0 0 13 8.277V4.723a.5.5 0 0 0-.448-.497A44.304 44.304 0 0 0 8 4Zm-3 7a1 1 0 1 0-2 0 1 1 0 0 0 2 0Zm8 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0Zm-7 0a1 1 0 0 0 1 1h2a1 1 0 1 0 0-2H7a1 1 0 0 0-1 1Z"/>
            </svg>
              </div>
              <h4 class="title">Transportation</h4>
              <p class="description">Hostel accommodation is allotted to 100% of the (girls) applicants and to the boys.</p>
            </div>
          </div>
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-bank" viewBox="0 0 16 16">
              <path d="m8 0 6.61 3h.89a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5H15v7a.5.5 0 0 1 .485.38l.5 2a.498.498 0 0 1-.485.62H.5a.498.498 0 0 1-.485-.62l.5-2A.501.501 0 0 1 1 13V6H.5a.5.5 0 0 1-.5-.5v-2A.5.5 0 0 1 .5 3h.89L8 0ZM3.777 3h8.447L8 1 3.777 3ZM2 6v7h1V6H2Zm2 0v7h2.5V6H4Zm3.5 0v7h1V6h-1Zm2 0v7H12V6H9.5ZM13 6v7h1V6h-1Zm2-1V4H1v1h14Zm-.39 9H1.39l-.25 1h13.72l-.25-1Z"/>
            </svg>
              </div>
              <h4 class="title">Bank/ATM</h4>
              <p class="description">Banking facilities includes such as 24-hour ATM, Online banking access and etc.</p>
            </div>
          </div>
          <div class="col-lg-4  col-md-6" data-aos="zoom-in">
            <div class="box ">
              <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="black" class="bi bi-wifi" viewBox="0 0 16 16">
             <path d="M15.384 6.115a.485.485 0 0 0-.047-.736A12.444 12.444 0 0 0 8 3C5.259 3 2.723 3.882.663 5.379a.485.485 0 0 0-.048.736.518.518 0 0 0 .668.05A11.448 11.448 0 0 1 8 4c2.507 0 4.827.802 6.716 2.164.205.148.49.13.668-.049z"/>
            <path d="M13.229 8.271a.482.482 0 0 0-.063-.745A9.455 9.455 0 0 0 8 6c-1.905 0-3.68.56-5.166 1.526a.48.48 0 0 0-.063.745.525.525 0 0 0 .652.065A8.46 8.46 0 0 1 8 7a8.46 8.46 0 0 1 4.576 1.336c.206.132.48.108.653-.065zm-2.183 2.183c.226-.226.185-.605-.1-.75A6.473 6.473 0 0 0 8 9c-1.06 0-2.062.254-2.946.704-.285.145-.326.524-.1.75l.015.015c.16.16.407.19.611.09A5.478 5.478 0 0 1 8 10c.868 0 1.69.201 2.42.56.203.1.45.07.61-.091l.016-.015zM9.06 12.44c.196-.196.198-.52-.04-.66A1.99 1.99 0 0 0 8 11.5a1.99 1.99 0 0 0-1.02.28c-.238.14-.236.464-.04.66l.706.706a.5.5 0 0 0 .707 0l.707-.707z"/>
            </svg>
              </div>
              <h4 class="title">Wi-Fi Connectivityries</h4>
              <p class="description">The campus LAN is connected via Fiber Optic cables with a secured Wi-Fi Facilities.</p>
            </div>
          </div>
        </div>
        </div>
    </div>

 
     <!-- contact -->
    <?php include_once 'assets/components/contact.php'; ?>

     <!-- footer -->
     <?php include_once 'assets/components/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  
<script>
      AOS.init();
    $(function() {
    $(window).on("scroll", function() {
        if($(window).scrollTop() > 50) {
            $(".header").addClass("active");
        } else {
            //remove the background property so it comes transparent again (defined in your css)
           $(".header").removeClass("active");
        }
    });
});
</script>  
</body>
</html>
<?php }
else {
  header("location:index.php");
  // echo "not validate";
}
?>