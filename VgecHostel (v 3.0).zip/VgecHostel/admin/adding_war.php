<?php

require_once '../connectdb.php';

 ECHO $sql = "INSERT INTO wardens(name,email,password,block) VALUES ('$_POST[name]', '$_POST[email]','$_POST[pass]','$_POST[block]'  )";
if(mysqli_query($conn, $sql)){
    header('Location: wardens.php');
}
?>