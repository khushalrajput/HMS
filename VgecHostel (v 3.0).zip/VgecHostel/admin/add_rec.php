<?php
session_start();

if ($_SESSION['admin'] == "true") {

    require_once '../connectdb.php';

  


?>
    <!doctype html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <link rel="stylesheet" href="cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="css/index.css">
        
        <style>
            #users {
                background-color: #00d4e8;
                color: white;
                font-weight: 800;
            }
        </style>
    </head>

    <body>
        <?php include 'components/sidebar.php';  ?>
        <div class="content">
        <div class="container">
        <div class="text-center fw-bold fs-2  my-5">
               Add Rector
            </div>
            <center>
            <form class="myform pt-5 mb-5 pb-3 " action="adding_rec.php" method="post">

            <div class="form-floating mb-3 col-5">
              <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name@example.com" value="" required>
              <label for="floatingInput">Full Name</label>
            </div>
            <div class="form-floating mb-3 col-5">
              <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com" value="" required>
              <label for="floatingInput">Email</label>
            </div>
       
            <div class="form-floating mb-3 col-5">
              <input type="password" name="pass" class="form-control" id="floatingInput" placeholder="name@example.com" value="" required>
              <label for="floatingInput">Password</label>
            </div>

<input type="submit" class="btn btn-info m-4" name="reserve" value="ADD">
<input type="reset" class="btn btn-warning m-4" name="cancel" value="CANCEL">
</form>
            </center>
 
        </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    </body>

    </html>

<?php
} else {
    header("location:../login.php");
}
?>