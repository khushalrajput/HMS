<?php

require_once '../connectdb.php';

 ECHO $sql = "INSERT INTO rectors(name,email,password) VALUES ('$_POST[name]', '$_POST[email]','$_POST[pass]' )";
if(mysqli_query($conn, $sql)){
    header('Location: rectors.php');
}
?>