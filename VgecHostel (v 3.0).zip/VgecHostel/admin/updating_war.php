<?php

require_once '../connectdb.php';

 $sql = "UPDATE WARDENS SET name = '$_POST[name]', email = '$_POST[email]',password = '$_POST[pass]',block = '$_POST[block]' WHERE war_id = '$_POST[id]'";
if(mysqli_query($conn, $sql)){
    header('Location: wardens.php');
}
?>