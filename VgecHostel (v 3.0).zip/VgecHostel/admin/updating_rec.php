<?php

require_once '../connectdb.php';

 $sql = "UPDATE rectors SET name = '$_POST[name]', email = '$_POST[email]',password = '$_POST[pass]' WHERE rec_id = '$_POST[id]'";
if(mysqli_query($conn, $sql)){
    header('Location: rectors.php');
}
?>