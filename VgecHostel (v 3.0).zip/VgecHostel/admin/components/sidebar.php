
<div class="sidebar">
<a id="home" class="" href="index.php">Home</a>
  <a id="rectors" class="" href="rectors.php">Rectors</a>
  <!-- <a id="" href="">Manage Rectors</a> -->
  <a id="wardens" href="wardens.php">Wardens</a>
  <!-- <a id="" href="feedbacks.php">Manage Wardens</a> -->
  <a id="" href="../logout.php">Logout</a>
  <!-- <a href="#about">About</a> -->
</div>

