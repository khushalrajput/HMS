<?php

require_once "../connectdb.php";

$sql = "DELETE FROM ".$_GET["table"]." WHERE ".$_GET["name"]." = '".$_GET["id"]."'";
    $result = mysqli_query($conn, $sql);
    if($result){
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }

?>