<?php

session_start();

$_SESSION['validation'] = "";

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="shortcut icon" href="assets/img/logo.png" type="image/x-icon">
    <title>Login</title>

    <style>
        .login-form{
            background-image: linear-gradient(45deg, #D0FFE9,#3EADCF);
            background-image: linear-gradient(45deg, #d3d3d3,#d3d3d3);
            width: 400px;
            min-width: 320px;
            /* height: 225px; */
            height: fit-content;
            min-height: 225px;
            border-radius: 20px;
            box-shadow: 20px 20px 72px -8px rgba(25,14,142,0.5);
            border: 2px double yellow;

        }
        input[type=submit]{
            
            background-image: linear-gradient(45deg, lime,green);
            width: 45%;
            font-weight: 700;
            color: white;
            border-radius: 10px;
        }
    body{
       /* min-height: 100vh; */
    }
    .main{
        min-height: 100vh;
    }
    .notification{
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
    }
    a{
    text-decoration: none;
    
}
    </style>
   
    <script>
        
    </script>
  </head>
  <body style=" background-color: rgb(224 244 255);" >
    
    <div class="container text-center">

        <div class="fs-1 head fw-bold ">
            <!-- Expense Tracker -->
        </div>

        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'success_reg') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-success alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/success.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Registration Successfull</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>
        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'fail_reg') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-danger alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/danger.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Registration Failed</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>
        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'alredy_exist') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-warning alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/warning.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">User Already Exist</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>

        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'incorrect') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-danger alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/danger.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Incorrect Password</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>

<?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'no_reg') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-warning alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/warning.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Please Do Registration First</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>


<?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'fail_login') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-danger alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/danger.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Failed To Logg In<br>Please Try Again</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>

        <div class="main d-flex justify-content-md-center justify-content-center  align-items-center flex-wrap">

       

            <form class="login-form form text-center px-5 pt-4 pb-3 m-5" method="POST" action="validate.php">
                <div class="logo pb-4">
                    <img src="assets/img/logo.png" height="150px" width="150" alt="">
                </div>
                <div class="form-floating mb-4">
                    <input type="email" class="form-control" name="email" id="email" oninput="getPassFeild();" placeholder="name@example.com" required>
                    <label for="floatingInput">Email Address</label>
                </div>

                
                <div class="form-floating mb-4">
                    <input type="password" class="form-control" name="pass" id="pass" placeholder="name@example.com" required>
                    <label for="floatingInput">Password</label>
                </div>
                

                  <div class="row d-flex justify-content-center align-items-center mt-5 ">
                    <input type="submit" class="btn" name="login" value="LOGIN">
                  </div>

                <div class="mt-3 ">
                Not registered yet ? <a href="registration.php">Register Now</a>  !!!
                </div>

            </form>

            
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>