<?php
 require_once 'connectdb.php';

 $sql="SELECT * from rooms where r_type='".$_POST['type']."' AND u_id IS NULL";
// echo $sql="SELECT * from rooms where r_type='AC (Attached Bathroom)' AND u_id IS NULL";
   try{
       // echo $chk;
       $result = mysqli_query($conn, $sql);
       echo mysqli_num_rows($result);
        if(mysqli_num_rows($result)!=0){
            // echo "not zero";
            while($row=mysqli_fetch_assoc($result)){
                echo "<option value='$row[r_no]'>$row[r_no]</option>";
           }
        }
        else{
            // echo " zero";
            echo "<option value=''>No Rooms Available</option>";
        }
   }
   catch(Exception $e){
    echo "<option value=''>Select Room Preferenec</option>";
    echo "<br>".$e->getMessage();
   }
?>