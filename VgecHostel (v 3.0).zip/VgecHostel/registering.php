<?php
session_start();
if(isset($_POST['register'])){

    require_once 'connectdb.php';
    require_once 'secure.php';

    $chk="SELECT email from users where email='".trim($_POST['email'])."'";
    try{
        echo $chk;
        $result_chk = mysqli_query($conn, $chk);
        
        if (mysqli_num_rows($result_chk)==1) {
            echo "alredy exist";
            $_SESSION['status'] = "alredy_exist";
            header("location:login.php");
            mysqli_close($conn);
        }
        else{
            $sql = "INSERT INTO users( name, email, mob, pass,enroll) VALUES ('"  . trim($_POST['name']) . "','" . trim($_POST['email']) ."','" . trim($_POST['mob']) ."','" .trim(encrypt($_POST['pass'])) ."','" .trim($_POST['enroll']) ."')";
            try {
                echo $sql;
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    echo "done";
                    $_SESSION['status'] = "success_reg";
                    header("location:login.php");
                    mysqli_close($conn);
                }
            } catch (Exception $e) {
                $_SESSION['status'] = "fail_reg";
                echo "fails";
                header("location:login.php");
                mysqli_close($conn);
            }
        }
    }
    catch (Exception $e) {
        echo $e->getMessage();
    }
}
else{
    header("location:registration.php");    
}
?>