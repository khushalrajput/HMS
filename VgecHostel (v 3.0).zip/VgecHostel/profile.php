<?php
session_start();
if( $_SESSION['validation']=="true"){
  error_reporting(E_ERROR | E_PARSE);
    // echo "".$_SESSION['u_id'];

    require_once 'connectdb.php';

    $sql="SELECT email,name,mob,enroll from users where u_id='".$_SESSION['u_id']."'";
      try{
          // echo $chk;
          $result = mysqli_query($conn, $sql);
          $row=mysqli_fetch_assoc($result);
      }
      catch(Exception $e){
        header("location:login.php");
      }
      $sql2="SELECT * from rooms where u_id='".$_SESSION['u_id']."'";
      $result2 = mysqli_query($conn, $sql2);
      $row2=mysqli_fetch_assoc($result2);
?>  
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
        #profile{
            font-weight: 900;
            color: white;
        }
        .login-form{
            background-image: linear-gradient(45deg, #D0FFE9,#3EADCF);
            background-image: linear-gradient(45deg, #d3d3d3,#d3d3d3);
            width: 400px;
            min-width: 320px;
            /* height: 225px; */
            height: fit-content;
            min-height: 225px;
            border-radius: 20px;
            box-shadow: 20px 20px 72px -8px rgba(25,14,142,0.5);
            border: 2px double yellow;

        }
       
    body{
       min-height: 100vh;
    }
 
    </style>
</head>
  <body style=" background-color: rgb(224 244 255);" >
     <!-- header -->
     <?php include_once 'assets/components/header_login.php'; ?>



    <div class=" mb-5 d-flex justify-content-center align-items-center " style="min-height: 100vh;">
      <div class="login-form d-flex justify-content-center align-items-center flex-wrap flex-direction-row">
        <div class="profile-img mt-3 mx-5">
          <img src="assets/img/profile.png" width="100px" height="100px" alt="">
        </div>
        <div class="text-start mt-3 p-3">
          <div class="mx-3"> <span class="fw-bold">Name : </span><span><?php echo $row['name']; ?></span> </div>
          <div class="mx-3"> <span class="fw-bold">Email : </span><span><?php echo $row['email']; ?></span> </div>
          <div class="mx-3"> <span class="fw-bold">Mobile No. : </span><span><?php echo $row['mob']; ?></span> </div>
          <!-- <div class="mx-3"> <span class="fw-bold">Enrollment No. : </span><span><?php echo $row['enroll']; ?></span> </div> -->
          <?php try{ if($row2['r_no']!=NULL){ ?>
          <div class="mx-3"> <span class="fw-bold text-e">Room No. Allocated : </span><span><?php echo $row2['r_no']; ?></span> </div>
		   
          <?php } }catch(Exception $e){echo "";}?>
        </div>
        <div class="my-3 mx-5">
         <form action="logout.php" method="post">
		 <?php 
		 
			function haversineGreatCircleDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
			  {
				// convert from degrees to radians
				$latFrom = deg2rad($latitudeFrom);
				$lonFrom = deg2rad($longitudeFrom);
				$latTo = deg2rad($latitudeTo);
				$lonTo = deg2rad($longitudeTo);
			  
				$latDelta = $latTo - $latFrom;
				$lonDelta = $lonTo - $lonFrom;
			  
				$angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) +
				  cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));
				return $angle * $earthRadius;
			  }
			if(haversineGreatCircleDistance(23.105745417978714,72.5952321508488,23.105745417978714,72.5952321508488) == 0)
			  {
				$enable = true;
			  }
			  else
			  {
				$enable = false;
			  }

		 ?>
		 
          <input type="submit" class="btn btn-danger" value="Logout">
         </form>
		  <form class="mt-3" action="mark_attain.php" method="post">
		 <input type="submit" class="btn btn-danger <?php if(!$enable){echo 'disabled';} ?>"  value="Attendance">
		 </form>
        </div>
      </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
<?php 

}
else{
header("location:index.php");
}
?>