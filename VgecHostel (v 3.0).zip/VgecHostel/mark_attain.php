<?php

require_once 'connectdb.php';
 session_start();
 $date=date("d/m/Y");
 echo $sql2 = "SELECT * FROM attendence WHERE u_id='$_SESSION[u_id]' AND Date='$date'";
 try{
    $result=mysqli_query($conn,$sql2);
    echo mysqli_num_rows($result);
    if(mysqli_num_rows($result)>=1){
        echo "done";
        echo "<script>alert('Your Attendence is Already marked for today !!!');</script>";
        echo "<script>  window.location.replace('profile.php');</script>";
      
        // header('Location: profile.php');
    }else{
        $sql = "INSERT INTO attendence(u_id,Date) VALUES('$_SESSION[u_id]','$date' )";
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Your Attendence is marked for today !!!');</script>";
        echo "<script>  window.location.replace('profile.php');</script>";
    }
    }
  
 }catch(Exception $e){
    echo "fail";
    echo $sql = "INSERT INTO attendence(u_id,Date) VALUES('$_SESSION[u_id]','$date' )";
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Your Attendence is marked for today !!!');</script>";
        echo "<script>  window.location.replace('profile.php');</script>";
    }
 }

?>