
<div class="fluid-container" id="feedback">
  <footer class="pt-3 pb-2 mt-4 bg-dark">
    <div class="d-flex justify-content-between align-itmes-center mb-2">
      <div class="logo d-flex justify-content-center align-items-center flex-wrap w-50 ">
        <div class="d-flex justify-content-center align-items-center w-100 " >
          <img src="assets/img/logo.png" alt="" height="140px" width="140px">
        </div>
        <p class="text-center text-light">© All Rights Reserved</p>
      </div>
      <div class="feedback w-50">
        <div class="text-center fs-4 fw-bold text-light p-3 pb-4">
          FeedBack
        </div>
        <form action="feedback.php" method="post" class="form">
          <div class="d-flex justify-content-evenly align-items-center">
            <div class="form-floating mb-3 col-5">
              <input type="text" name="feed_name" class="form-control" id="floatingInput" placeholder="name@example.com" required>
              <label for="floatingInput">Name</label>
            </div>
            <div class="form-floating mb-3 col-5">
              <input type="text" name="feed_email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
              <label for="floatingInput">Email</label>
            </div>
          </div>
          <div class="d-flex justify-content-evenly align-items-center">
            <div class="form-floating col-8">
              <textarea class="form-control" placeholder="Leave a feedback here" id="floatingTextarea2" name="feed" style="height: 120px"></textarea>
              <label for="floatingTextarea2">Feedback</label>

            </div>
            <input class="btn btn-info m-4" type="submit" value="Submit">
          </div>
        </form>
      </div>
    </div>

    
  </footer>
</div>