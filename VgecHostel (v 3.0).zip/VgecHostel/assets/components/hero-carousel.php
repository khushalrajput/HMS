<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/carousel.css">
    <link rel="stylesheet" href="assets/css/index.css">
</head>
<body>
<div class="carousel" style="margin-top: 70px">
  <div class="carousel__slides" tabindex="0">


    <div class="carousel__slide">
      <div class="carousel__slide-content">
        <h2 class="carousel__slide-title">VGEC Hostel</h2>
        <p class="carousel__slide-description">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio.
          Quisque volutpat mattis eros. Nullam malesuada erat ut turpis.
          Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.
        </p>
        <!-- <a href="#0" class="carousel__slide-button">Find out more</a> -->
      </div>
      <img
        src="assets/img/caraousel/0.jpg"
        class="carousel__slide-image"
        alt="Image"
      />
    </div>

    <div class="carousel__slide">
      <div class="carousel__slide-content">
        <h2 class="carousel__slide-title">VGEC Hostel</h2>
        <p class="carousel__slide-description">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio.
          Quisque volutpat mattis eros. Nullam malesuada erat ut turpis.
          Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.
        </p>
        <!-- <a href="#0" class="carousel__slide-button">Find out more</a> -->
      </div>
      <img
        src="assets/img/caraousel/1.jpg"
        class="carousel__slide-image"
        alt="Image"
      />
    </div>

    <div class="carousel__slide">
      <div class="carousel__slide-content">
        <h2 class="carousel__slide-title">VGEC Hostel</h2>
        <p class="carousel__slide-description">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio.
          Quisque volutpat mattis eros. Nullam malesuada erat ut turpis.
          Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.
        </p>
        <!-- <a href="#0" class="carousel__slide-button">Find out more</a> -->
      </div>
      <img
        src="assets/img/caraousel/2.jpg"
        class="carousel__slide-image"
        alt="Image"
      />
    </div>

    <div class="carousel__slide">
      <div class="carousel__slide-content">
        <h2 class="carousel__slide-title">VGEC Hostel</h2>
        <p class="carousel__slide-description">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio.
          Quisque volutpat mattis eros. Nullam malesuada erat ut turpis.
          Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.
        </p>
        <!-- <a href="#0" class="carousel__slide-button">Find out more</a> -->
      </div>
      <img
        src="assets/img/caraousel/3.jpg"
        class="carousel__slide-image"
        alt="Image"
      />
    </div>

    <div class="carousel__slide">
      <div class="carousel__slide-content">
        <h2 class="carousel__slide-title">VGEC Hostel</h2>
        <p class="carousel__slide-description">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio.
          Quisque volutpat mattis eros. Nullam malesuada erat ut turpis.
          Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.
        </p>
        <!-- <a href="#0" class="carousel__slide-button">Find out more</a> -->
      </div>
      <img
        src="assets/img/caraousel/4.jpg"
        class="carousel__slide-image"
        alt="Image"
      />
    </div>

  </div>
  <div class="carousel__controls"></div>
<script >
    const Carousel = carousel => {
  // Variables
  const slides = carousel.querySelector(".carousel__slides");
  const controls = carousel.querySelector(".carousel__controls");
  const carouselSpeed = 5000;
  let current;
  let carouselCycle;

  // Functions
  const carouselInit = () => {
    current = slides.firstElementChild;
    createControls();
    current.classList.add("carousel__slide--current");

    // Beginning the cycle
    carouselCycle = setInterval(() => {
      nextSlide();
    }, carouselSpeed);
  };

  // Updates the carousel by taking in the target slide
  const updateCarousel = target => {
    // Pause the cycle
    clearInterval(carouselCycle);

    // Removing active class from current slide
    Array.from(slides.children).forEach(el =>
      el.classList.remove("carousel__slide--current")
    );

    // Set active class on new current slide
    target.classList.add("carousel__slide--current");

    // Get index of new slide and update controls
    const targetIndex = getCurrentSlideIndex(target);
    updateControls(targetIndex);

    // Updating current variable
    current = target;

    // Restart carousel cycle
    carouselCycle = setInterval(() => {
      nextSlide();
    }, carouselSpeed);
  };

  const nextSlide = () => {
    updateCarousel(current.nextElementSibling || slides.firstElementChild);
  };

  const prevSlide = () => {
    updateCarousel(current.previousElementSibling || slides.lastElementChild);
  };

  // Handling the indicator buttons on click
  const handleControls = (_el, index) => {
    const newSlide = Array.from(slides.children)[index];
    updateCarousel(newSlide);
    carouselCycle;
  };

  // Keyboard nav (tabindex set on 'carousel__slides' div)
  const handleKeyPress = e => {
    let target;
    if (e.key === "ArrowRight") {
      target = current.nextElementSibling || slides.firstElementChild;
    } else if (e.key === "ArrowLeft") {
      target = current.previousElementSibling || slides.lastElementChild;
    } else {
      return;
    }
    updateCarousel(target);
  };

  const createControls = () => {
    const numberOfSlides = slides.children.length;
    for (let i = 0; i < numberOfSlides; i++) {
      const indicator = document.createElement("div");
      indicator.setAttribute("role", "button");
      indicator.setAttribute("class", "carousel__control");
      controls.insertAdjacentElement("beforeend", indicator);
    }
    controls.firstElementChild.classList.add("carousel__control--current");
    const controlIndicators = Array.from(controls.children);
    controlIndicators.forEach((el, index) => {
      el.addEventListener("click", () => handleControls(el, index));
    });
  };

  const updateControls = index => {
    const indicators = Array.from(
      controls.querySelectorAll(".carousel__control")
    );
    indicators.forEach(el => el.classList.remove("carousel__control--current"));
    indicators[index].classList.add("carousel__control--current");
  };

  const getCurrentSlideIndex = currentSlide => {
    const index = Array.from(
      slides.querySelectorAll(".carousel__slide")
    ).findIndex(slide => slide === currentSlide);
    return index;
  };

  // Touch/Swipe support
  const handleSwipe = e => {
    const startPos = e.touches[0].clientX;
    const threshold = 120;
    const touchEnd = e => {
      slides.removeEventListener("touchend", touchEnd);
      const endPos = e.changedTouches[0].clientX;
      if (startPos < endPos && endPos - startPos > threshold) {
        prevSlide();
      } else if (startPos > endPos && startPos - endPos > threshold) {
        nextSlide();
      }
    };
    slides.addEventListener("touchend", touchEnd);
  };

  // Initiating the carousel on load
  carouselInit();

  // Listeners
  slides.addEventListener("keydown", handleKeyPress);
  slides.parentElement.addEventListener("touchstart", handleSwipe);
};

const carousel = Carousel(document.querySelector(".carousel"));
</script>
</div>
</body>
</html>