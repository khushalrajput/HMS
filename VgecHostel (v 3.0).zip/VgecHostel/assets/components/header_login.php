<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<style>
.mynav{
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
    width: 100%;
    
}
.header{
    -webkit-transition: all ease-out .3s;
  -moz-transition: all ease-out .3s;
  -o-transition: all ease-out .3s;
  transition: all ease-out .3s;
  background: black;
  /* background: pink; */
}
.active {
  background-color: rgba(34,34,34,0.8);
}
</style>
</head>
<body>
<div  class="">
<nav class="navbar navbar-expand-lg header navbar-dark fw-bold mynav ">
    <!-- <nav class="navbar navbar-expand-lg navbar-dark bg-dark mynav"> -->
        <div class="container-fluid">
            <a href="#" class="navbar-brand me-5">
                <img src="assets/img/logo.png" height="45" alt="">
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ">
                    <a id="" href="home.php#Home" class="nav-item nav-link mx-3">Home</a>
                    <a id="" href="#Services" class="nav-item nav-link mx-3">Services</a>
                    <a id="" href="#Glances" class="nav-item nav-link mx-3">Glances</a>
                    <a id="" href="#Facility" class="nav-item nav-link mx-3">Facility</a>
                    <a id="" href="#Contact" class="nav-item nav-link mx-3">Contact</a>
                    <a id="" href="#feedback" class="nav-item nav-link mx-3">Feedback</a>
                    <!-- <a id="" href="login.php" class="nav-item nav-link mx-3">Login/Register</a> -->
                    <a id="" href="book.php" class="nav-item nav-link mx-3">Room Booking</a>
                    <a id="" href="leave.php" class="nav-item nav-link mx-3">Leave Application</a>
                    <a id="" href="services.php" class="nav-item nav-link mx-3">Room Services</a>
                    <a id="" href="profile.php" class="nav-item nav-link mx-3">Profile</a>
                </div>
                
            </div>
        </div>
    </nav>
</div>
<script>

</script>
</body>
</html>