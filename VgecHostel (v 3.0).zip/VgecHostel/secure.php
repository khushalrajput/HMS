<?php

$key="KhushalRajputSinghS";
$iv = '1234567891011121';
$ciphering = "AES-128-CTR";
$iv_length = openssl_cipher_iv_length($ciphering);
$options = 0;

function encrypt($msg){

    global $ciphering;
    global $key;
    global $options;
    global $iv;

    return openssl_encrypt($msg, $ciphering, $key, $options, $iv);

}

function decrypt($enc){

    global $ciphering;
    global $key;
    global $options;
    global $iv;

    return openssl_decrypt ($enc, $ciphering, $key, $options, $iv);

}
// echo "<br>Khushal Rajput";
// echo "<br>".encrypt("Khushal Rajput");
echo "<br>".decrypt("/A==");
// echo encrypt("2");
?>