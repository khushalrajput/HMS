
<div class="sidebar">
<h1 class="text-center text-light pt-3">Warden 1</h1>
<a id="h" class="" href="index.php">Hostlers</a>
<a id="al" class="" href="attendence_list.php">Attendence List</a>
<!-- <a id="users" class="" href="registered.php">Registered Users</a> -->
   <!--  <a id="hostelers" href="hostelers.php">Hostelers</a>
  <a id="rooms" href="rooms.php">Rooms</a>
  <a id="feed" href="feedbacks.php">Feedbacks</a> -->
  <a id="" href="../logout.php">Logout</a>
  <!-- <a href="#about">About</a> -->
</div>

