<?php
session_start();
if ($_SESSION["validation"] == "true") {

  require_once 'connectdb.php';

  $sql="SELECT email,name,mob,enroll from users where u_id='".$_SESSION['u_id']."'";
    try{
        // echo $chk;
        $result = mysqli_query($conn, $sql);
        $row=mysqli_fetch_assoc($result);
    }
    catch(Exception $e){
      header("location:login.php");
    }

?>
  <!doctype html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Room Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="css/index.css">
    <style>
      #booking {
        font-weight: 900;
        color: white;
      }

      .myform {
        width: 500px;
        /* background-image: linear-gradient(45deg, #D0FFE9,#3EADCF); */
        background-image: linear-gradient(45deg, #d3d3d3,#d3d3d3);
        min-width: 320px;
        /* height: 225px; */
        height: fit-content;
        min-height: 225px;
        border-radius: 20px;
        box-shadow: 20px 20px 72px -8px rgba(25,14,142,0.5);
        border: 2px double yellow;
      }
      .notification{
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
    }
    body{
    
     /* display: none; */
    }
    h2{
        color: rgb(14, 13, 232);
      }
    </style>
  </head>

  <body style=" background-color: rgb(224 244 255);">

   
         <!-- header -->
         <?php include_once 'assets/components/header_login.php'; 
    echo "<br><br><br";
    ?>
    <div class="container">

      <div class="text-center fs-3 fw-bold mt-5" style="color: rgb(14, 13, 232);">
        Room Booking
      </div>

      <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'allocated') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-warning alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/warning.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">A Room Is Already Allocated To You !!!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>
        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'booked') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-success alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/success.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Room Reserved</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>
        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'failed') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-danger alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="assets/img/extra/danger.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Failed To Reserve Room<br>Please Try Again Later</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>

      <div class=" mt-5 d-flex justify-content-center align-items-center">
        <form class="myform pt-5 mb-5 pb-3 d-flex justify-content-center align-items-center flex-wrap" action="admission_req.php" method="post">


          <div class="form-floating mb-3 col-9">
            <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name@example.com" value="<?php echo $row['name']; ?>" required>
            <label for="floatingInput">Full Name</label>
          </div>
          
          <div class="form-floating mb-3 col-9">
            <input type="number" name="enroll" class="form-control" id="floatingInput" placeholder="name@example.com" value="<?php echo $row['enroll']; ?>" required >
            <label for="floatingInput">Enrollment No.</label>
          </div>
          
          
          <div class="form-floating mb-3 col-9">
            <select class="form-select" id="floatingSelect" name="gender" aria-label="Floating label select example" required>
              <option selected disabled>Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
            <label for="floatingSelect"> Gender</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <input type="date" name="dob" class="form-control" id="floatingInput" placeholder="name@example.com" required>
            <label for="floatingInput">DOB</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <input type="text" name="clg" class="form-control" id="floatingInput" placeholder="name@example.com" required>
            <label for="floatingInput">College Name</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <select class="form-select" id="floatingSelect" name="branch" aria-label="Floating label select example" required>
              <option selected disabled>Select Branch</option>
              <option value="Information Technology">Information Technology</option>
              <option value="Computer">Computer</option>
              <option value="Civil">Civil</option>
              <option value="Mechanical">Mechanical</option>
              <option value="Electrical">Electrical</option>
            </select>
            <label for="floatingSelect">Branch</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <select class="form-select" id="floatingSelect" name="sem" aria-label="Floating label select example" required>
              <option selected disabled>Select Semester</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
            </select>
            <label for="floatingSelect">Semester</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <select class="form-select" id="floatingSelect" name="bg" aria-label="Floating label select example" required>
              <option selected disabled>Select Blood Group</option>
              <option value="A">A</option>
              <option value="A+">A+</option>
              <option value="B">B</option>
              <option value="B+">B+</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
            <label for="floatingSelect">Blood Group</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <textarea class="form-control" name="address" placeholder="Enter Address" id="floatingTextarea" required minlength="15"></textarea>
            <label for="floatingTextarea">Address</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <input type="number" name="pin" class="form-control" placeholder="name@example.com" minlength="6" maxlength="6"   value="<?php  ?>"  required>
            <label for="floatingInput">Your Pin Code</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <input type="email" name="email" class="form-control" placeholder="name@example.com"  value="<?php echo $row['email']; ?>"  required disabled>
            <label for="floatingInput">Enter Email</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <input type="number" name="mob-1" class="form-control" placeholder="name@example.com" minlength="10"  value="<?php echo $row['mob']; ?>"  required>
            <label for="floatingInput">Your Mobile Number</label>
          </div>
          <div class="form-floating mb-3 col-9">
            <input type="number" name="mob2" class="form-control" placeholder="name@example.com" minlength="10" required>
            <label for="floatingInput">Parent's Mobile Number</label>
          </div>

          <div class="form-floating mb-3 col-9">
            <input type="number" name="merit" class="form-control" placeholder="name@example.com" minlength="10" required>
            <label for="floatingInput">Merit Rank</label>
          </div>
           
          <div class="form-floating mb-3 col-9">
            <select class="form-select" name="cast" id="cast" aria-label="Floating label select example" required>
              <option selected disabled>Select Category</option>
              <option value="1">SC/ST</option>
              <option value="2">OBC</option>
              <option value="3">EWS</option>
              <option value="4">Open Category</option>
            </select>
            <label for="floatingSelect">Select Category</label>
          </div>

          <input type="submit" class="btn btn-info m-4" name="reserve" value="RESERVE">
          <input type="reset" class="btn btn-warning m-4" name="cancel" value="CANCEL">
        </form>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
        <script>
            $(document).ready(function() {
                $('#room-type').on('change', function() {
                  console.log('ch');
                    var type = this.value;
                    $.ajax({
                        url: "getrooms.php",
                        type: "POST",
                        data: {
                            type: type
                        },
                        cache: false,
                        success: function(result) {
                            $("#room-no").html(result);
                        }
                    });
                });
            });
         </script>
  </body>

  </html>

<?php

} else {
  header("location:index.php");
}
?>