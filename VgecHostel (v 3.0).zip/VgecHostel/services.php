<?php session_start(); ?>

<!doctype html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SERVICES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="css/index.css">
    <style>
      #booking {
        font-weight: 900;
        color: white;
      }

      .myform {
        width: 500px;
        /* background-image: linear-gradient(45deg, #D0FFE9,#3EADCF); */
        background-image: linear-gradient(45deg, #d3d3d3,#d3d3d3);
        min-width: 320px;1  
        /* height: 225px; */
        height: fit-content;
        min-height: 225px;
        border-radius: 20px;
        box-shadow: 20px 20px 72px -8px rgba(25,14,142,0.5);
        border: 2px double yellow;
      }
      .notification{
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
    }
    
    body{
    
     /* display: none; */
    }
    h2{
        color: rgb(14, 13, 232);
      }
    </style>
  </head>

  <body style=" background-color: rgb(224 244 255);">


    <div class="container">

      <div class="text-center fs-3 fw-bold" style="color: rgb(14, 13, 232);">
        SERVICES
      </div>

         <!-- header -->
         <?php include_once 'assets/components/header_login.php'; 
    echo "<br><br><br";
    ?>
      <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'allocated') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-warning alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="images/extra/warning.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">A Room Is Already Allocated To You !!!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>
        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'booked') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-success alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="images/extra/success.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Room Reserved</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>
        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == 'failed') {
        ?>  
        <div class="d-flex justify-content-center notification">
        <div class="d-flex justify-content-evenly align-items-center alert alert-danger alert-dismissible fade show " role="alert">
        <img class="m-1 align-self-start" src="images/extra/danger.png" height="75px" width="75px" alt="">
                <strong class="m-1 ms-4">Failed To Reserve Room<br>Please Try Again Later</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>
        <?php
            unset($_SESSION['status']);
        } 
        ?>

      <div class=" mt-5 d-flex justify-content-center align-items-center">
        <form class="myform pt-5 pb-3 d-flex justify-content-center align-items-center flex-wrap" action="booking.php" method="post">


          <div class="form-floating mb-3 col-9">
            <input type="text" name="name" class="form-control" id="floatingInput" placeholder="Name" value="<?php echo " krina";?>" required>
            <label for="floatingInput">Name</label>
          </div>          

          
          <div class="form-floating mb-3 col-9">
            <input type="Text" name="date" class="form-control" id="floatingInput" required>
            <label for="floatingInput">Room number</label>
          </div>

          <div class="form-floating mb-3 col-9">
          <select class="form-select" aria-label="Default select example">
  <option selected>--SELECT SERVICES--</option>
  <option value="1">Electrician</option>
  <option value="2">Plumber</option>
  <option value="3">Sweeper</option>
  <option value="3">Meal</option>
  <option value="4">Others</option>
  
</select>
    </div>

    <div class="form-floating mb-3 col-9">
            
            <textarea name="desc" class="form-control" id="floatingInput" required></textarea>
            <label for="floatingInput">Description</label>
          </div>



<div class="form-floating mb-3 col-9 d-flex justify-content-center align-items-evenly">
            
          <input type="submit" class="btn btn-info m-4 px-4" name="submit" value="SUBMIT">
          <input type="reset" class="btn btn-warning m-4 px-4" name="cancel" value="CANCEL">
          </div>

        </form>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
        <script>
            $(document).ready(function() {
                $('#room-type').on('change', function() {
                  console.log('ch');
                    var type = this.value;
                    $.ajax({
                        url: "getrooms.php",
                        type: "POST",
                        data: {
                            type: type
                        },
                        cache: false,
                        success: function(result) {
                            $("#room-no").html(result);
                        }
                    });
                });
            });
         </script>
  </body>

  </html>