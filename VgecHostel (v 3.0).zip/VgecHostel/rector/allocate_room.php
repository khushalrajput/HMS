<?php
session_start();


require_once '../connectdb.php';

 echo $sql = "UPDATE admissions SET block = '$_POST[block]',status='allocated' WHERE a_id = '$_POST[id]'";
if(mysqli_query($conn, $sql)){
    header('Location: admission_reqs.php');
}
?>