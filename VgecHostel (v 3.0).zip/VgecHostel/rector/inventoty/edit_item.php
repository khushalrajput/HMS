<!DOCTYPE html>
<html>
<head>
    <title>Edit Item</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<?php
    // Check if the form has been submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Connect to the database
        $conn = mysqli_connect("localhost", "root", "", "hostel_inventory");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Get the values from the form
        $name = $_POST["name"];
        $quantity = $_POST["quantity"];
        $id = $_POST["id"];
        $supplier_name = $_POST["supplier_name"];
        $supplier_contact = $_POST["supplier_contact"];

        // Update the item in the database
        $sql = "UPDATE inventory SET name='$name', quantity='$quantity', supplier_name='$supplier_name', supplier_contact='$supplier_contact' WHERE id='$id'";
        if (mysqli_query($conn, $sql)) {
            header("Location: inventory.php"); // Redirect to inventory page
        } else {
            echo "Error updating item: " . mysqli_error($conn);
        }

        mysqli_close($conn); // Close the database connection
    } else {
        // Connect to the database
        $conn = mysqli_connect("localhost", "root", "", "hostel_inventory");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Get the ID of the item to edit
        $id = $_GET["id"];

        // Select the item from the inventory table
        $sql = "SELECT * FROM inventory WHERE id='$id'";
        $result = mysqli_query($conn, $sql);
		$result = mysqli_query($conn, $sql);
if (!$result) {
    echo "Error: " . mysqli_error($conn);
    exit;
}

        // Check if the item exists
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            $name = $row["name"];
            $quantity = $row["quantity"];
            $supplier_contact = $row["supplier_contact"];
            $supplier_name = $row["supplier_name"];
        } else {
            echo "Item not found.";
            exit;
        }
		
		$result = mysqli_query($conn, $sql);
if (!$result) {
    echo "Error: " . mysqli_error($conn);
    exit;
}

        mysqli_close($conn); // Close the database connection
    }
?>

<div class="container-fluid">
    <h2>Edit Item</h2>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <div class="form-group">
            <label for="item_name">Item Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
        </div>
        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo $quantity; ?>" required>
        </div>
        <div class="form-group">
            <label for="supplier_name">supplier_name:</label>
            <input type="text" class="form-control" id="supplier_name" name="supplier_name" value="<?php echo $supplier_name; ?>" required>
        </div>
        <div class="form-group">
            <label for="supplier_contact">supplier_contact:</label>
            <input type="number" class="form-control" id="supplier_contact" name="supplier_contact" value="<?php echo $supplier_contact; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>