<!DOCTYPE html>
<html>
<head>
	<title>Hostel Inventory</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid">
		<h2 align="center">Hostel Inventory</h2>
		<table class="table table-striped table-bordered">
			<thead>
				<tr>
					<th>Item Name</th>
					<th>Quantity</th>
					<th>Price</th>
					<th>Supplier_Name</th>
					<th>Supplier_Contact</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				// Connect to the database
				$conn = mysqli_connect("localhost", "root", "", "hostel_inventory");

				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}

				// Select all items from the inventory table
				$sql = "SELECT * FROM inventory";
				$result = mysqli_query($conn, $sql);

				// Loop through the results and display them in a table
				if (mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
						echo "<tr>";
						echo "<td>" . $row["name"] . "</td>";
						echo "<td>" . $row["quantity"] . "</td>";
						echo "<td>" . $row["price"] . "</td>";
						echo "<td>" . $row["supplier_name"] . "</td>";
						echo "<td>" . $row["supplier_contact"] . "</td>";
						echo "<td><a href='edit_item.php?id=" . $row["id"] . "' class='btn btn-primary'>Edit</a> <a href='delete_item.php?id=" . $row["id"] . "' class='btn btn-danger'>Delete</a></td>";
						echo "</tr>";
					}
				} else {
					echo "<tr><td colspan='3'>No items found in inventory.</td></tr>";
				}

				mysqli_close($conn); // Close the database connection
				?>
			</tbody>
		</table>
		<a href="add_item.php" class="btn btn-success">Add Item</a>
	</div>
</body>
</html>