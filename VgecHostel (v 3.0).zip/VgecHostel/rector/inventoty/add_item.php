<?php
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "hostel_inventory");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables
$name = $description = $price = $quantity = $supplier_name = $supplier_contact = "";
$nameErr = $descriptionErr = $priceErr = $quantityErr = $supplier_nameErr = $supplier_contactErr = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
    }

    // Validate description
    if (empty($_POST["description"])) {
        $descriptionErr = "Description is required";
    } else {
        $description = test_input($_POST["description"]);
    }

    // Validate price
    if (empty($_POST["price"])) {
        $priceErr = "Price is required";
    } else {
        $price = test_input($_POST["price"]);
        // Check if price is a valid number
        if (!is_numeric($price)) {
            $priceErr = "Price must be a number";
        }
    }

    // Validate quantityff
    if (empty($_POST["quantity"])) {
        $quantityErr = "Quantity is required";
    } else {
        $quantity = test_input($_POST["quantity"]);
        // Check if quantity is a valid number
        if (!is_numeric($quantity)) {
            $quantityErr = "Quantity must be a number";
        }
    }

    if (empty($_POST["supplier_name"])) {
        $supplier_nameErr = "supplier_name is required";
    } else {
        $supplier_name = test_input($_POST["supplier_name"]);
       
        }
    }

    if (empty($_POST["supplier_contact"])) {
        $supplier_contactErr = "Quantity is required";
    } else {
        $supplier_contact = test_input($_POST["supplier_contact"]);
        // Check if quantity is a valid number
        if (!is_numeric($supplier_contact)) {
            $supplier_contactErr = "supplier_contact must be a number";
        }
    }

    // Add item to database if no errors
    if ($nameErr == "" && $descriptionErr == "" && $priceErr == "" && $quantityErr == "" && $supplier_nameErr == "" && $supplier_contactErr == "") {
        $sql = "INSERT INTO inventory (name, description, price, quantity ,supplier_name ,supplier_contact) VALUES ('$name', '$description', $price, $quantity ,$supplier_name ,$supplier_contact)";

        if (mysqli_query($conn, $sql)) {
            echo "<div class='alert alert-success'>Item added successfully</div>";
            $name = $description = $price = $quantity = $supplier_name = $supplier_contact = "";
        } else {
            echo "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
        }
    }


// Close database connection
mysqli_close($conn);

// Function to sanitize form inputs
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Item - Hostel Inventory</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
<br>
    <h1 align="center">Add Item</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>">
            <span class="text-danger"><?php echo $nameErr; ?></span>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description"><?php echo $description; ?></textarea>
            <span class="text-danger"><?php echo $descriptionErr; ?></span>
        </div>
		<div class="form-group">
            <label for="price">Price:</label>
            <input type="text" class="form-control" id="price" name="price" value="<?php echo $price; ?>">
            <span class="text-danger"><?php echo $priceErr; ?></span>
        </div>
        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo $quantity; ?>">
            <span class="text-danger"><?php echo $quantityErr; ?></span>
        </div>
        <div class="form-group">
            <label for="supplier_name">Supplier_name</label>
            <input type="text" class="form-control" id="supplier_name" name="supplier_name" value="<?php echo $supplier_name; ?>">
            <span class="text-danger"></span>
        </div>
        <div class="form-group">
            <label for="supplier_contact">Supplier_contact</label>
            <input type="text" class="form-control" id="supplier_contact" name="supplier_contact" value="<?php echo $supplier_contact; ?>">
            <span class="text-danger"><?php ?></span>
        </div>
        <button type="submit" class="btn btn-primary">Add Item</button>
    </form>
</div>

</body>
</html>