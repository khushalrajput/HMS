<?php
// Include database configuration file
include_once("config.php");
$conn = mysqli_connect("localhost", "root", "", "hostel_inventory");

if(isset($_GET['id']) && !empty($_GET['id'])){
    $id = $_GET['id'];
    
    // Fetch item details from database
    $sql = "SELECT * FROM items WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $sql = "DELETE FROM inventory WHERE id = $id";
if (mysqli_query($conn, $sql)) {
    // query was successful, redirect to inventory page
    header("Location: inventory.php");
    exit();
} else {
    // query failed, display error message
    echo "Error deleting record: " . mysqli_error($conn);
}
    
    // Close database connection
    mysqli_close($conn);
} else {
    // If item ID is not set, redirect to inventory page
    header("Location: inventory.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Item</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h1>Delete Item</h1>
    <div class="row">
        <div class="col-md-6">
            <form method="post" action="delete.php?id=<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['name']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" name="description" rows="3" readonly><?php echo $row['description']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="quantity">Quantity:</label>
                    <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="supplier_name">supplier_name:</label>
                    <input type="text" class="form-control" id="supplier_name" name="supplier_name" value="<?php echo $row['supplier_name']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="supplier_contact">supplier_contact:</label>
                    <input type="number" class="form-control" id="supplier_contact" name="supplier_contact" value="<?php echo $row['supplier_contact']; ?>" readonly>
                </div>
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal">Delete</button>
                <a href="inventory.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>

<!-- Delete confirmation modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this item?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Item</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.2/js/bootstrap.min.js"></script>

</body>
</html>