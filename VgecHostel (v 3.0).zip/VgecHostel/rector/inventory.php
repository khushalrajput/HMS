<?php
session_start();

if ($_SESSION['admin'] == "true") {

    require_once '../connectdb.php';
?>
    <!doctype html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <link rel="stylesheet" href="cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="css/index.css">
        
        <style>
            #inventory {
                background-color: #00d4e8;
                color: white;
                font-weight: 800;
            }
            a{
                text-decoration: none;
            }
        </style>
    </head>

    <body>
        <?php include 'components/sidebar.php';  ?>
        <div class="content">
        <div class="container">
            <div class="text-center fw-bold fs-2  my-5">
       
            </div>

            <div class="container-fluid">
		<h2 align="center">Hostel Inventory</h2>
		<table class="table table-striped table-bordered">
			<thead>
				<tr>
					<th>Item Name</th>
					<th>Quantity</th>
					<th>Price</th>
					<th>Supplier_Name</th>
					<th>Supplier_Contact</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				// Connect to the database
				$conn = mysqli_connect("localhost", "root", "", "hostel2");

				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}

				// Select all items from the inventory table
				$sql = "SELECT * FROM inventory";
				$result = mysqli_query($conn, $sql);

				// Loop through the results and display them in a table
				if (mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
						echo "<tr>";
						echo "<td>" . $row["name"] . "</td>";
						echo "<td>" . $row["quantity"] . "</td>";
						echo "<td>" . $row["price"] . "</td>";
						echo "<td>" . $row["supplier_name"] . "</td>";
						echo "<td>" . $row["supplier_contact"] . "</td>";
						echo "<td><a href='edit_item.php?id=" . $row["id"] . "' class='btn btn-primary'>Edit</a> <a href='delete_item.php?id=" . $row["id"] . "' class='btn btn-danger'>Delete</a></td>";
						echo "</tr>";
					}
				} else {
					echo "<tr><td colspan='3'>No items found in inventory.</td></tr>";
				}

				mysqli_close($conn); // Close the database connection
				?>
			</tbody>
		</table>
		<a href="add_item.php" class="btn btn-success">Add Item</a>
	</div>
        </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    </body>

    </html>

<?php
} else {
    header("location:../login.php");
}
?>