<?php
session_start();


require_once '../connectdb.php';

 echo $sql = "UPDATE admissions SET status='pending' WHERE a_id = '$_GET[a_id]'";
if(mysqli_query($conn, $sql)){
    header('Location: admission_reqs.php');
}
?>